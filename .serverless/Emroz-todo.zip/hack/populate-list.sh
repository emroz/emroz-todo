# Get initial list of todos (see empty list)
alias pop1="curl $SERVERLESS_GOOF_HOST/dev/todos/ | jq"

# Add an item
alias pop2="curl -X POST $SERVERLESS_GOOF_HOST/dev/todos/ --data '{ \"text\": \"Call Mom\" }'"

# Add another item
alias pop3="curl -X POST $SERVERLESS_GOOF_HOST/dev/todos/ --data '{ \"text\": \"Learn Serverless\" }'"

# Add an item with a reminder
alias pop4="curl -X POST $SERVERLESS_GOOF_HOST/dev/todos/ --data '{ \"text\": \"Learn Serverless in 3 days\" }'"

# Get list of todos again (see 3 items)
alias pop5="curl $SERVERLESS_GOOF_HOST/dev/todos/ | jq"

# See rendered list (mobile first)
alias pop6="echo $SERVERLESS_GOOF_HOST/dev/todos/render"

# See rendered list for Desktop
alias pop7="echo $SERVERLESS_GOOF_HOST'/dev/todos/render?device=Desktop'"

# See rendered list for Desktop
alias pop8="cat ../todos/render.dust"

alias pop9="curl https://s62vws0kbi.execute-api.us-east-1.amazonaws.com/dev/todos/ | jq"

# Cleanup - delete all items
# alias curl $SERVERLESS_GOOF_HOST/dev/todos/ | jq '.[]|.id' | cut -d'"' -f2 | awk '{print "curl -X DELETE $SERVERLESS_GOOF_HOST/dev/todos/"$0}' | bash
